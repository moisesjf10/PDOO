package deepspace;

import java.util.ArrayList;

public class SpaceCity extends SpaceStation{
    private SpaceStation base;
    private ArrayList<SpaceStation> collaborators;
    public SpaceCity (SpaceStation base, ArrayList<SpaceStation> rest){

    }

    public SpaceStation getCollaborators(){

    }

    public float fire(){

    }

    public float protection(){

    }

    public Transformation setLoot(Loot loot){

    }

    @Override
    public SpaceCityToUI getUIversion() {

    }
}