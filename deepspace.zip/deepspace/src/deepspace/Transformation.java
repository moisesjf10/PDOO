package deepspace;

public enum Transformation{
    NOTRANSFORM, GETEFFICIENT, SPACECITY
}