package deepspace;

public interface SpaceFighter {
    public float fire();

    public float protection();

    public ShotResult receiveShot(float shot);

}