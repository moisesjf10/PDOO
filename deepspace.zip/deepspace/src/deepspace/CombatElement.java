package deepspace;

public interface CombatElement {
    public int getUses();

    public float useIt();
}