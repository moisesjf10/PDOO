
package deepspace;

public enum GameCharacter {
    ENEMYSTARSHIP, SPACESTATION
}
