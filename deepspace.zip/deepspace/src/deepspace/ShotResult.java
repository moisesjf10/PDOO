
package deepspace;

public enum ShotResult {
    DONOTRESIST, RESIST
}

