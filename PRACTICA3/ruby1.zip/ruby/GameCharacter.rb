#encoding: utf-8
#Representanta a los dos tipos de personajes del juego

module Deepspace
	module GameCharacter
		SPACESTATION=:spacestation
		ENEMYSTARSHIP=:enemystarship
	end
end
