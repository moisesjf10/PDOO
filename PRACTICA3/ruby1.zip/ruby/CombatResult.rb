#encoding: utf-8
#Este enumerado representa todos los resultados posibles de un combate 
#entre una estación espacial y una nave enemiga.

module Deepspace
	module CombatResult
		ENEMYWINS=:enenemywins
		NOCOMBAT=:nocombat
		STATIONESCAPES=:stationescapes
		STATIONWINS=:stationwins
	end
end

